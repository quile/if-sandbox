/* This file was generated automatically by the Snowball to ISO C++ compiler */

#include <limits.h>
#include "french.h"

static const symbol s_pool[] = {
#define s_0_0 0
'c', 'o', 'l',
#define s_0_1 3
'p', 'a', 'r',
#define s_0_2 6
't', 'a', 'p',
#define s_1_1 9
'I',
#define s_1_2 10
'U',
#define s_1_3 11
'Y',
#define s_2_0 12
'i', 'q', 'U',
#define s_2_1 15
'a', 'b', 'l',
#define s_2_2 18
'I', 0xC3, 0xA8, 'r',
#define s_2_3 22
'i', 0xC3, 0xA8, 'r',
#define s_2_4 26
'e', 'u', 's',
#define s_2_5 29
'i', 'v',
#define s_3_0 31
'i', 'c',
#define s_3_1 33
'a', 'b', 'i', 'l',
#define s_3_2 37
'i', 'v',
#define s_4_0 39
'i', 'q', 'U', 'e',
#define s_4_1 43
'a', 't', 'r', 'i', 'c', 'e',
#define s_4_2 49
'a', 'n', 'c', 'e',
#define s_4_3 53
'e', 'n', 'c', 'e',
#define s_4_4 57
'l', 'o', 'g', 'i', 'e',
#define s_4_5 62
'a', 'b', 'l', 'e',
#define s_4_6 66
'i', 's', 'm', 'e',
#define s_4_7 70
'e', 'u', 's', 'e',
#define s_4_8 74
'i', 's', 't', 'e',
#define s_4_9 78
'i', 'v', 'e',
#define s_4_10 81
'i', 'f',
#define s_4_11 83
'u', 's', 'i', 'o', 'n',
#define s_4_12 88
'a', 't', 'i', 'o', 'n',
#define s_4_13 93
'u', 't', 'i', 'o', 'n',
#define s_4_14 98
'a', 't', 'e', 'u', 'r',
#define s_4_15 103
'i', 'q', 'U', 'e', 's',
#define s_4_16 108
'a', 't', 'r', 'i', 'c', 'e', 's',
#define s_4_17 115
'a', 'n', 'c', 'e', 's',
#define s_4_18 120
'e', 'n', 'c', 'e', 's',
#define s_4_19 125
'l', 'o', 'g', 'i', 'e', 's',
#define s_4_20 131
'a', 'b', 'l', 'e', 's',
#define s_4_21 136
'i', 's', 'm', 'e', 's',
#define s_4_22 141
'e', 'u', 's', 'e', 's',
#define s_4_23 146
'i', 's', 't', 'e', 's',
#define s_4_24 151
'i', 'v', 'e', 's',
#define s_4_25 155
'i', 'f', 's',
#define s_4_26 158
'u', 's', 'i', 'o', 'n', 's',
#define s_4_27 164
'a', 't', 'i', 'o', 'n', 's',
#define s_4_28 170
'u', 't', 'i', 'o', 'n', 's',
#define s_4_29 176
'a', 't', 'e', 'u', 'r', 's',
#define s_4_30 182
'm', 'e', 'n', 't', 's',
#define s_4_31 187
'e', 'm', 'e', 'n', 't', 's',
#define s_4_32 193
'i', 's', 's', 'e', 'm', 'e', 'n', 't', 's',
#define s_4_33 202
'i', 't', 0xC3, 0xA9, 's',
#define s_4_34 207
'm', 'e', 'n', 't',
#define s_4_35 211
'e', 'm', 'e', 'n', 't',
#define s_4_36 216
'i', 's', 's', 'e', 'm', 'e', 'n', 't',
#define s_4_37 224
'a', 'm', 'm', 'e', 'n', 't',
#define s_4_38 230
'e', 'm', 'm', 'e', 'n', 't',
#define s_4_39 236
'a', 'u', 'x',
#define s_4_40 239
'e', 'a', 'u', 'x',
#define s_4_41 243
'e', 'u', 'x',
#define s_4_42 246
'i', 't', 0xC3, 0xA9,
#define s_5_0 250
'i', 'r', 'a',
#define s_5_1 253
'i', 'e',
#define s_5_2 255
'i', 's', 's', 'e',
#define s_5_3 259
'i', 's', 's', 'a', 'n', 't', 'e',
#define s_5_4 266
'i',
#define s_5_5 267
'i', 'r', 'a', 'i',
#define s_5_6 271
'i', 'r',
#define s_5_7 273
'i', 'r', 'a', 's',
#define s_5_8 277
'i', 'e', 's',
#define s_5_9 280
0xC3, 0xAE, 'm', 'e', 's',
#define s_5_10 285
'i', 's', 's', 'e', 's',
#define s_5_11 290
'i', 's', 's', 'a', 'n', 't', 'e', 's',
#define s_5_12 298
0xC3, 0xAE, 't', 'e', 's',
#define s_5_13 303
'i', 's',
#define s_5_14 305
'i', 'r', 'a', 'i', 's',
#define s_5_15 310
'i', 's', 's', 'a', 'i', 's',
#define s_5_16 316
'i', 'r', 'i', 'o', 'n', 's',
#define s_5_17 322
'i', 's', 's', 'i', 'o', 'n', 's',
#define s_5_18 329
'i', 'r', 'o', 'n', 's',
#define s_5_19 334
'i', 's', 's', 'o', 'n', 's',
#define s_5_20 340
'i', 's', 's', 'a', 'n', 't', 's',
#define s_5_21 347
'i', 't',
#define s_5_22 349
'i', 'r', 'a', 'i', 't',
#define s_5_23 354
'i', 's', 's', 'a', 'i', 't',
#define s_5_24 360
'i', 's', 's', 'a', 'n', 't',
#define s_5_25 366
'i', 'r', 'a', 'I', 'e', 'n', 't',
#define s_5_26 373
'i', 's', 's', 'a', 'I', 'e', 'n', 't',
#define s_5_27 381
'i', 'r', 'e', 'n', 't',
#define s_5_28 386
'i', 's', 's', 'e', 'n', 't',
#define s_5_29 392
'i', 'r', 'o', 'n', 't',
#define s_5_30 397
0xC3, 0xAE, 't',
#define s_5_31 400
'i', 'r', 'i', 'e', 'z',
#define s_5_32 405
'i', 's', 's', 'i', 'e', 'z',
#define s_5_33 411
'i', 'r', 'e', 'z',
#define s_5_34 415
'i', 's', 's', 'e', 'z',
#define s_6_0 420
'a',
#define s_6_1 421
'e', 'r', 'a',
#define s_6_2 424
'a', 's', 's', 'e',
#define s_6_3 428
'a', 'n', 't', 'e',
#define s_6_4 432
0xC3, 0xA9, 'e',
#define s_6_5 435
'a', 'i',
#define s_6_6 437
'e', 'r', 'a', 'i',
#define s_6_7 441
'e', 'r',
#define s_6_8 443
'a', 's',
#define s_6_9 445
'e', 'r', 'a', 's',
#define s_6_10 449
0xC3, 0xA2, 'm', 'e', 's',
#define s_6_11 454
'a', 's', 's', 'e', 's',
#define s_6_12 459
'a', 'n', 't', 'e', 's',
#define s_6_13 464
0xC3, 0xA2, 't', 'e', 's',
#define s_6_14 469
0xC3, 0xA9, 'e', 's',
#define s_6_15 473
'a', 'i', 's',
#define s_6_16 476
'e', 'r', 'a', 'i', 's',
#define s_6_17 481
'i', 'o', 'n', 's',
#define s_6_18 485
'e', 'r', 'i', 'o', 'n', 's',
#define s_6_19 491
'a', 's', 's', 'i', 'o', 'n', 's',
#define s_6_20 498
'e', 'r', 'o', 'n', 's',
#define s_6_21 503
'a', 'n', 't', 's',
#define s_6_22 507
0xC3, 0xA9, 's',
#define s_6_23 510
'a', 'i', 't',
#define s_6_24 513
'e', 'r', 'a', 'i', 't',
#define s_6_25 518
'a', 'n', 't',
#define s_6_26 521
'a', 'I', 'e', 'n', 't',
#define s_6_27 526
'e', 'r', 'a', 'I', 'e', 'n', 't',
#define s_6_28 533
0xC3, 0xA8, 'r', 'e', 'n', 't',
#define s_6_29 539
'a', 's', 's', 'e', 'n', 't',
#define s_6_30 545
'e', 'r', 'o', 'n', 't',
#define s_6_31 550
0xC3, 0xA2, 't',
#define s_6_32 553
'e', 'z',
#define s_6_33 555
'i', 'e', 'z',
#define s_6_34 558
'e', 'r', 'i', 'e', 'z',
#define s_6_35 563
'a', 's', 's', 'i', 'e', 'z',
#define s_6_36 569
'e', 'r', 'e', 'z',
#define s_6_37 573
0xC3, 0xA9,
#define s_7_0 575
'e',
#define s_7_1 576
'I', 0xC3, 0xA8, 'r', 'e',
#define s_7_2 581
'i', 0xC3, 0xA8, 'r', 'e',
#define s_7_3 586
'i', 'o', 'n',
#define s_7_4 589
'I', 'e', 'r',
#define s_7_5 592
'i', 'e', 'r',
#define s_7_6 595
0xC3, 0xAB,
#define s_8_0 597
'e', 'l', 'l',
#define s_8_1 600
'e', 'i', 'l', 'l',
#define s_8_2 604
'e', 'n', 'n',
#define s_8_3 607
'o', 'n', 'n',
#define s_8_4 610
'e', 't', 't',
};


static const struct among a_0[3] =
{
/*  0 */ { 3, s_0_0, -1, -1},
/*  1 */ { 3, s_0_1, -1, -1},
/*  2 */ { 3, s_0_2, -1, -1}
};


static const struct among a_1[4] =
{
/*  0 */ { 0, 0, -1, 4},
/*  1 */ { 1, s_1_1, 0, 1},
/*  2 */ { 1, s_1_2, 0, 2},
/*  3 */ { 1, s_1_3, 0, 3}
};


static const struct among a_2[6] =
{
/*  0 */ { 3, s_2_0, -1, 3},
/*  1 */ { 3, s_2_1, -1, 3},
/*  2 */ { 4, s_2_2, -1, 4},
/*  3 */ { 4, s_2_3, -1, 4},
/*  4 */ { 3, s_2_4, -1, 2},
/*  5 */ { 2, s_2_5, -1, 1}
};


static const struct among a_3[3] =
{
/*  0 */ { 2, s_3_0, -1, 2},
/*  1 */ { 4, s_3_1, -1, 1},
/*  2 */ { 2, s_3_2, -1, 3}
};


static const struct among a_4[43] =
{
/*  0 */ { 4, s_4_0, -1, 1},
/*  1 */ { 6, s_4_1, -1, 2},
/*  2 */ { 4, s_4_2, -1, 1},
/*  3 */ { 4, s_4_3, -1, 5},
/*  4 */ { 5, s_4_4, -1, 3},
/*  5 */ { 4, s_4_5, -1, 1},
/*  6 */ { 4, s_4_6, -1, 1},
/*  7 */ { 4, s_4_7, -1, 11},
/*  8 */ { 4, s_4_8, -1, 1},
/*  9 */ { 3, s_4_9, -1, 8},
/* 10 */ { 2, s_4_10, -1, 8},
/* 11 */ { 5, s_4_11, -1, 4},
/* 12 */ { 5, s_4_12, -1, 2},
/* 13 */ { 5, s_4_13, -1, 4},
/* 14 */ { 5, s_4_14, -1, 2},
/* 15 */ { 5, s_4_15, -1, 1},
/* 16 */ { 7, s_4_16, -1, 2},
/* 17 */ { 5, s_4_17, -1, 1},
/* 18 */ { 5, s_4_18, -1, 5},
/* 19 */ { 6, s_4_19, -1, 3},
/* 20 */ { 5, s_4_20, -1, 1},
/* 21 */ { 5, s_4_21, -1, 1},
/* 22 */ { 5, s_4_22, -1, 11},
/* 23 */ { 5, s_4_23, -1, 1},
/* 24 */ { 4, s_4_24, -1, 8},
/* 25 */ { 3, s_4_25, -1, 8},
/* 26 */ { 6, s_4_26, -1, 4},
/* 27 */ { 6, s_4_27, -1, 2},
/* 28 */ { 6, s_4_28, -1, 4},
/* 29 */ { 6, s_4_29, -1, 2},
/* 30 */ { 5, s_4_30, -1, 15},
/* 31 */ { 6, s_4_31, 30, 6},
/* 32 */ { 9, s_4_32, 31, 12},
/* 33 */ { 5, s_4_33, -1, 7},
/* 34 */ { 4, s_4_34, -1, 15},
/* 35 */ { 5, s_4_35, 34, 6},
/* 36 */ { 8, s_4_36, 35, 12},
/* 37 */ { 6, s_4_37, 34, 13},
/* 38 */ { 6, s_4_38, 34, 14},
/* 39 */ { 3, s_4_39, -1, 10},
/* 40 */ { 4, s_4_40, 39, 9},
/* 41 */ { 3, s_4_41, -1, 1},
/* 42 */ { 4, s_4_42, -1, 7}
};


static const struct among a_5[35] =
{
/*  0 */ { 3, s_5_0, -1, 1},
/*  1 */ { 2, s_5_1, -1, 1},
/*  2 */ { 4, s_5_2, -1, 1},
/*  3 */ { 7, s_5_3, -1, 1},
/*  4 */ { 1, s_5_4, -1, 1},
/*  5 */ { 4, s_5_5, 4, 1},
/*  6 */ { 2, s_5_6, -1, 1},
/*  7 */ { 4, s_5_7, -1, 1},
/*  8 */ { 3, s_5_8, -1, 1},
/*  9 */ { 5, s_5_9, -1, 1},
/* 10 */ { 5, s_5_10, -1, 1},
/* 11 */ { 8, s_5_11, -1, 1},
/* 12 */ { 5, s_5_12, -1, 1},
/* 13 */ { 2, s_5_13, -1, 1},
/* 14 */ { 5, s_5_14, 13, 1},
/* 15 */ { 6, s_5_15, 13, 1},
/* 16 */ { 6, s_5_16, -1, 1},
/* 17 */ { 7, s_5_17, -1, 1},
/* 18 */ { 5, s_5_18, -1, 1},
/* 19 */ { 6, s_5_19, -1, 1},
/* 20 */ { 7, s_5_20, -1, 1},
/* 21 */ { 2, s_5_21, -1, 1},
/* 22 */ { 5, s_5_22, 21, 1},
/* 23 */ { 6, s_5_23, 21, 1},
/* 24 */ { 6, s_5_24, -1, 1},
/* 25 */ { 7, s_5_25, -1, 1},
/* 26 */ { 8, s_5_26, -1, 1},
/* 27 */ { 5, s_5_27, -1, 1},
/* 28 */ { 6, s_5_28, -1, 1},
/* 29 */ { 5, s_5_29, -1, 1},
/* 30 */ { 3, s_5_30, -1, 1},
/* 31 */ { 5, s_5_31, -1, 1},
/* 32 */ { 6, s_5_32, -1, 1},
/* 33 */ { 4, s_5_33, -1, 1},
/* 34 */ { 5, s_5_34, -1, 1}
};


static const struct among a_6[38] =
{
/*  0 */ { 1, s_6_0, -1, 3},
/*  1 */ { 3, s_6_1, 0, 2},
/*  2 */ { 4, s_6_2, -1, 3},
/*  3 */ { 4, s_6_3, -1, 3},
/*  4 */ { 3, s_6_4, -1, 2},
/*  5 */ { 2, s_6_5, -1, 3},
/*  6 */ { 4, s_6_6, 5, 2},
/*  7 */ { 2, s_6_7, -1, 2},
/*  8 */ { 2, s_6_8, -1, 3},
/*  9 */ { 4, s_6_9, 8, 2},
/* 10 */ { 5, s_6_10, -1, 3},
/* 11 */ { 5, s_6_11, -1, 3},
/* 12 */ { 5, s_6_12, -1, 3},
/* 13 */ { 5, s_6_13, -1, 3},
/* 14 */ { 4, s_6_14, -1, 2},
/* 15 */ { 3, s_6_15, -1, 3},
/* 16 */ { 5, s_6_16, 15, 2},
/* 17 */ { 4, s_6_17, -1, 1},
/* 18 */ { 6, s_6_18, 17, 2},
/* 19 */ { 7, s_6_19, 17, 3},
/* 20 */ { 5, s_6_20, -1, 2},
/* 21 */ { 4, s_6_21, -1, 3},
/* 22 */ { 3, s_6_22, -1, 2},
/* 23 */ { 3, s_6_23, -1, 3},
/* 24 */ { 5, s_6_24, 23, 2},
/* 25 */ { 3, s_6_25, -1, 3},
/* 26 */ { 5, s_6_26, -1, 3},
/* 27 */ { 7, s_6_27, 26, 2},
/* 28 */ { 6, s_6_28, -1, 2},
/* 29 */ { 6, s_6_29, -1, 3},
/* 30 */ { 5, s_6_30, -1, 2},
/* 31 */ { 3, s_6_31, -1, 3},
/* 32 */ { 2, s_6_32, -1, 2},
/* 33 */ { 3, s_6_33, 32, 2},
/* 34 */ { 5, s_6_34, 33, 2},
/* 35 */ { 6, s_6_35, 33, 3},
/* 36 */ { 4, s_6_36, 32, 2},
/* 37 */ { 2, s_6_37, -1, 2}
};


static const struct among a_7[7] =
{
/*  0 */ { 1, s_7_0, -1, 3},
/*  1 */ { 5, s_7_1, 0, 2},
/*  2 */ { 5, s_7_2, 0, 2},
/*  3 */ { 3, s_7_3, -1, 1},
/*  4 */ { 3, s_7_4, -1, 2},
/*  5 */ { 3, s_7_5, -1, 2},
/*  6 */ { 2, s_7_6, -1, 4}
};


static const struct among a_8[5] =
{
/*  0 */ { 3, s_8_0, -1, -1},
/*  1 */ { 4, s_8_1, -1, -1},
/*  2 */ { 3, s_8_2, -1, -1},
/*  3 */ { 3, s_8_3, -1, -1},
/*  4 */ { 3, s_8_4, -1, -1}
};

static const unsigned char g_v[] = { 17, 65, 16, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 130, 103, 8, 5 };

static const unsigned char g_keep_with_s[] = { 1, 65, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128 };

static const symbol s_0[] = { 'U' };
static const symbol s_1[] = { 'I' };
static const symbol s_2[] = { 'Y' };
static const symbol s_3[] = { 'Y' };
static const symbol s_4[] = { 'U' };
static const symbol s_5[] = { 'i' };
static const symbol s_6[] = { 'u' };
static const symbol s_7[] = { 'y' };
static const symbol s_8[] = { 'i', 'c' };
static const symbol s_9[] = { 'i', 'q', 'U' };
static const symbol s_10[] = { 'l', 'o', 'g' };
static const symbol s_11[] = { 'u' };
static const symbol s_12[] = { 'e', 'n', 't' };
static const symbol s_13[] = { 'a', 't' };
static const symbol s_14[] = { 'e', 'u', 'x' };
static const symbol s_15[] = { 'i' };
static const symbol s_16[] = { 'a', 'b', 'l' };
static const symbol s_17[] = { 'i', 'q', 'U' };
static const symbol s_18[] = { 'a', 't' };
static const symbol s_19[] = { 'i', 'c' };
static const symbol s_20[] = { 'i', 'q', 'U' };
static const symbol s_21[] = { 'e', 'a', 'u' };
static const symbol s_22[] = { 'a', 'l' };
static const symbol s_23[] = { 'e', 'u', 'x' };
static const symbol s_24[] = { 'a', 'n', 't' };
static const symbol s_25[] = { 'e', 'n', 't' };
static const symbol s_26[] = { 'i' };
static const symbol s_27[] = { 'g', 'u' };
static const symbol s_28[] = { 0xC3, 0xA9 };
static const symbol s_29[] = { 0xC3, 0xA8 };
static const symbol s_30[] = { 'e' };
static const symbol s_31[] = { 'i' };
static const symbol s_32[] = { 0xC3, 0xA7 };
static const symbol s_33[] = { 'c' };

int Xapian::InternalStemFrench::r_prelude() { /* forwardmode */
    while(1) { /* repeat, line 38 */
        int c1 = c;
        while(1) { /* goto, line 38 */
            int c2 = c;
            {   int c3 = c; /* or, line 44 */
                if (in_grouping_U(g_v, 97, 251, 0)) goto lab3; /* grouping v, line 40 */
                bra = c; /* [, line 40 */
                {   int c4 = c; /* or, line 40 */
                    if (c == l || p[c] != 'u') goto lab5;
                    c++;
                    ket = c; /* ], line 40 */
                    if (in_grouping_U(g_v, 97, 251, 0)) goto lab5; /* grouping v, line 40 */
                    {   int ret = slice_from_s(1, s_0); /* <-, line 40 */
                        if (ret < 0) return ret;
                    }
                    goto lab4;
                lab5:
                    c = c4;
                    if (c == l || p[c] != 'i') goto lab6;
                    c++;
                    ket = c; /* ], line 41 */
                    if (in_grouping_U(g_v, 97, 251, 0)) goto lab6; /* grouping v, line 41 */
                    {   int ret = slice_from_s(1, s_1); /* <-, line 41 */
                        if (ret < 0) return ret;
                    }
                    goto lab4;
                lab6:
                    c = c4;
                    if (c == l || p[c] != 'y') goto lab3;
                    c++;
                    ket = c; /* ], line 42 */
                    {   int ret = slice_from_s(1, s_2); /* <-, line 42 */
                        if (ret < 0) return ret;
                    }
                }
            lab4:
                goto lab2;
            lab3:
                c = c3;
                bra = c; /* [, line 45 */
                if (c == l || p[c] != 'y') goto lab7;
                c++;
                ket = c; /* ], line 45 */
                if (in_grouping_U(g_v, 97, 251, 0)) goto lab7; /* grouping v, line 45 */
                {   int ret = slice_from_s(1, s_3); /* <-, line 45 */
                    if (ret < 0) return ret;
                }
                goto lab2;
            lab7:
                c = c3;
                if (c == l || p[c] != 'q') goto lab1;
                c++;
                bra = c; /* [, line 47 */
                if (c == l || p[c] != 'u') goto lab1;
                c++;
                ket = c; /* ], line 47 */
                {   int ret = slice_from_s(1, s_4); /* <-, line 47 */
                    if (ret < 0) return ret;
                }
            }
        lab2:
            c = c2;
            break;
        lab1:
            c = c2;
            {   int ret = skip_utf8(p, c, 0, l, 1);
                if (ret < 0) goto lab0;
                c = ret; /* goto, line 38 */
            }
        }
        continue;
    lab0:
        c = c1;
        break;
    }
    return 1;
}

int Xapian::InternalStemFrench::r_mark_regions() { /* forwardmode */
    I_pV = l; /* pV = <integer expression>, line 52 */
    I_p1 = l; /* p1 = <integer expression>, line 53 */
    I_p2 = l; /* p2 = <integer expression>, line 54 */
    {   int c1 = c; /* do, line 56 */
        {   int c2 = c; /* or, line 58 */
            if (in_grouping_U(g_v, 97, 251, 0)) goto lab2; /* grouping v, line 57 */
            if (in_grouping_U(g_v, 97, 251, 0)) goto lab2; /* grouping v, line 57 */
            {   int ret = skip_utf8(p, c, 0, l, 1);
                if (ret < 0) goto lab2;
                c = ret; /* next, line 57 */
            }
            goto lab1;
        lab2:
            c = c2;
            if (c + 2 >= l || p[c + 2] >> 5 != 3 || !((331776 >> (p[c + 2] & 0x1f)) & 1)) goto lab3; /* among, line 59 */
            if (!(find_among(s_pool, a_0, 3, 0, 0))) goto lab3;
            goto lab1;
        lab3:
            c = c2;
            {   int ret = skip_utf8(p, c, 0, l, 1);
                if (ret < 0) goto lab0;
                c = ret; /* next, line 66 */
            }
            {   int ret = out_grouping_U(g_v, 97, 251, 1); /* gopast */ /* grouping v, line 66 */
                if (ret < 0) goto lab0;
                c += ret;
            }
        }
    lab1:
        I_pV = c; /* setmark pV, line 67 */
    lab0:
        c = c1;
    }
    {   int c3 = c; /* do, line 69 */
        {   int ret = out_grouping_U(g_v, 97, 251, 1); /* gopast */ /* grouping v, line 70 */
            if (ret < 0) goto lab4;
            c += ret;
        }
        {   int ret = in_grouping_U(g_v, 97, 251, 1); /* gopast */ /* non v, line 70 */
            if (ret < 0) goto lab4;
            c += ret;
        }
        I_p1 = c; /* setmark p1, line 70 */
        {   int ret = out_grouping_U(g_v, 97, 251, 1); /* gopast */ /* grouping v, line 71 */
            if (ret < 0) goto lab4;
            c += ret;
        }
        {   int ret = in_grouping_U(g_v, 97, 251, 1); /* gopast */ /* non v, line 71 */
            if (ret < 0) goto lab4;
            c += ret;
        }
        I_p2 = c; /* setmark p2, line 71 */
    lab4:
        c = c3;
    }
    return 1;
}

int Xapian::InternalStemFrench::r_postlude() { /* forwardmode */
    int among_var;
    while(1) { /* repeat, line 75 */
        int c1 = c;
        bra = c; /* [, line 77 */
        if (c >= l || p[c + 0] >> 5 != 2 || !((35652096 >> (p[c + 0] & 0x1f)) & 1)) among_var = 4; else /* substring, line 77 */
        among_var = find_among(s_pool, a_1, 4, 0, 0);
        if (!(among_var)) goto lab0;
        ket = c; /* ], line 77 */
        switch(among_var) { /* among, line 77 */
            case 0: goto lab0;
            case 1:
                {   int ret = slice_from_s(1, s_5); /* <-, line 78 */
                    if (ret < 0) return ret;
                }
                break;
            case 2:
                {   int ret = slice_from_s(1, s_6); /* <-, line 79 */
                    if (ret < 0) return ret;
                }
                break;
            case 3:
                {   int ret = slice_from_s(1, s_7); /* <-, line 80 */
                    if (ret < 0) return ret;
                }
                break;
            case 4:
                {   int ret = skip_utf8(p, c, 0, l, 1);
                    if (ret < 0) goto lab0;
                    c = ret; /* next, line 81 */
                }
                break;
        }
        continue;
    lab0:
        c = c1;
        break;
    }
    return 1;
}

int Xapian::InternalStemFrench::r_RV() { /* backwardmode */
    if (!(I_pV <= c)) return 0; /* pV <= <integer expression>, line 87 */
    return 1;
}

int Xapian::InternalStemFrench::r_R1() { /* backwardmode */
    if (!(I_p1 <= c)) return 0; /* p1 <= <integer expression>, line 88 */
    return 1;
}

int Xapian::InternalStemFrench::r_R2() { /* backwardmode */
    if (!(I_p2 <= c)) return 0; /* p2 <= <integer expression>, line 89 */
    return 1;
}

int Xapian::InternalStemFrench::r_standard_suffix() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 92 */
    among_var = find_among_b(s_pool, a_4, 43, 0, 0); /* substring, line 92 */
    if (!(among_var)) return 0;
    bra = c; /* ], line 92 */
    switch(among_var) { /* among, line 92 */
        case 0: return 0;
        case 1:
            {   int ret = r_R2(); /* call R2, line 96 */
                if (ret <= 0) return ret;
            }
            if (slice_del() == -1) return -1; /* delete, line 96 */
            break;
        case 2:
            {   int ret = r_R2(); /* call R2, line 99 */
                if (ret <= 0) return ret;
            }
            if (slice_del() == -1) return -1; /* delete, line 99 */
            {   int m1 = l - c; (void)m1; /* try, line 100 */
                ket = c; /* [, line 100 */
                if (!(eq_s_b(2, s_8))) { c = l - m1; goto lab0; } /* literal, line 100 */
                bra = c; /* ], line 100 */
                {   int m2 = l - c; (void)m2; /* or, line 100 */
                    {   int ret = r_R2(); /* call R2, line 100 */
                        if (ret == 0) goto lab2;
                        if (ret < 0) return ret;
                    }
                    if (slice_del() == -1) return -1; /* delete, line 100 */
                    goto lab1;
                lab2:
                    c = l - m2;
                    {   int ret = slice_from_s(3, s_9); /* <-, line 100 */
                        if (ret < 0) return ret;
                    }
                }
            lab1:
            lab0:
                ;
            }
            break;
        case 3:
            {   int ret = r_R2(); /* call R2, line 104 */
                if (ret <= 0) return ret;
            }
            {   int ret = slice_from_s(3, s_10); /* <-, line 104 */
                if (ret < 0) return ret;
            }
            break;
        case 4:
            {   int ret = r_R2(); /* call R2, line 107 */
                if (ret <= 0) return ret;
            }
            {   int ret = slice_from_s(1, s_11); /* <-, line 107 */
                if (ret < 0) return ret;
            }
            break;
        case 5:
            {   int ret = r_R2(); /* call R2, line 110 */
                if (ret <= 0) return ret;
            }
            {   int ret = slice_from_s(3, s_12); /* <-, line 110 */
                if (ret < 0) return ret;
            }
            break;
        case 6:
            {   int ret = r_RV(); /* call RV, line 114 */
                if (ret <= 0) return ret;
            }
            if (slice_del() == -1) return -1; /* delete, line 114 */
            {   int m3 = l - c; (void)m3; /* try, line 115 */
                ket = c; /* [, line 116 */
                among_var = find_among_b(s_pool, a_2, 6, 0, 0); /* substring, line 116 */
                if (!(among_var)) { c = l - m3; goto lab3; }
                bra = c; /* ], line 116 */
                switch(among_var) { /* among, line 116 */
                    case 0: { c = l - m3; goto lab3; }
                    case 1:
                        {   int ret = r_R2(); /* call R2, line 117 */
                            if (ret == 0) { c = l - m3; goto lab3; }
                            if (ret < 0) return ret;
                        }
                        if (slice_del() == -1) return -1; /* delete, line 117 */
                        ket = c; /* [, line 117 */
                        if (!(eq_s_b(2, s_13))) { c = l - m3; goto lab3; } /* literal, line 117 */
                        bra = c; /* ], line 117 */
                        {   int ret = r_R2(); /* call R2, line 117 */
                            if (ret == 0) { c = l - m3; goto lab3; }
                            if (ret < 0) return ret;
                        }
                        if (slice_del() == -1) return -1; /* delete, line 117 */
                        break;
                    case 2:
                        {   int m4 = l - c; (void)m4; /* or, line 118 */
                            {   int ret = r_R2(); /* call R2, line 118 */
                                if (ret == 0) goto lab5;
                                if (ret < 0) return ret;
                            }
                            if (slice_del() == -1) return -1; /* delete, line 118 */
                            goto lab4;
                        lab5:
                            c = l - m4;
                            {   int ret = r_R1(); /* call R1, line 118 */
                                if (ret == 0) { c = l - m3; goto lab3; }
                                if (ret < 0) return ret;
                            }
                            {   int ret = slice_from_s(3, s_14); /* <-, line 118 */
                                if (ret < 0) return ret;
                            }
                        }
                    lab4:
                        break;
                    case 3:
                        {   int ret = r_R2(); /* call R2, line 120 */
                            if (ret == 0) { c = l - m3; goto lab3; }
                            if (ret < 0) return ret;
                        }
                        if (slice_del() == -1) return -1; /* delete, line 120 */
                        break;
                    case 4:
                        {   int ret = r_RV(); /* call RV, line 122 */
                            if (ret == 0) { c = l - m3; goto lab3; }
                            if (ret < 0) return ret;
                        }
                        {   int ret = slice_from_s(1, s_15); /* <-, line 122 */
                            if (ret < 0) return ret;
                        }
                        break;
                }
            lab3:
                ;
            }
            break;
        case 7:
            {   int ret = r_R2(); /* call R2, line 129 */
                if (ret <= 0) return ret;
            }
            if (slice_del() == -1) return -1; /* delete, line 129 */
            {   int m5 = l - c; (void)m5; /* try, line 130 */
                ket = c; /* [, line 131 */
                if (c - 1 <= lb || p[c - 1] >> 5 != 3 || !((4198408 >> (p[c - 1] & 0x1f)) & 1)) { c = l - m5; goto lab6; } /* substring, line 131 */
                among_var = find_among_b(s_pool, a_3, 3, 0, 0);
                if (!(among_var)) { c = l - m5; goto lab6; }
                bra = c; /* ], line 131 */
                switch(among_var) { /* among, line 131 */
                    case 0: { c = l - m5; goto lab6; }
                    case 1:
                        {   int m6 = l - c; (void)m6; /* or, line 132 */
                            {   int ret = r_R2(); /* call R2, line 132 */
                                if (ret == 0) goto lab8;
                                if (ret < 0) return ret;
                            }
                            if (slice_del() == -1) return -1; /* delete, line 132 */
                            goto lab7;
                        lab8:
                            c = l - m6;
                            {   int ret = slice_from_s(3, s_16); /* <-, line 132 */
                                if (ret < 0) return ret;
                            }
                        }
                    lab7:
                        break;
                    case 2:
                        {   int m7 = l - c; (void)m7; /* or, line 133 */
                            {   int ret = r_R2(); /* call R2, line 133 */
                                if (ret == 0) goto lab10;
                                if (ret < 0) return ret;
                            }
                            if (slice_del() == -1) return -1; /* delete, line 133 */
                            goto lab9;
                        lab10:
                            c = l - m7;
                            {   int ret = slice_from_s(3, s_17); /* <-, line 133 */
                                if (ret < 0) return ret;
                            }
                        }
                    lab9:
                        break;
                    case 3:
                        {   int ret = r_R2(); /* call R2, line 134 */
                            if (ret == 0) { c = l - m5; goto lab6; }
                            if (ret < 0) return ret;
                        }
                        if (slice_del() == -1) return -1; /* delete, line 134 */
                        break;
                }
            lab6:
                ;
            }
            break;
        case 8:
            {   int ret = r_R2(); /* call R2, line 141 */
                if (ret <= 0) return ret;
            }
            if (slice_del() == -1) return -1; /* delete, line 141 */
            {   int m8 = l - c; (void)m8; /* try, line 142 */
                ket = c; /* [, line 142 */
                if (!(eq_s_b(2, s_18))) { c = l - m8; goto lab11; } /* literal, line 142 */
                bra = c; /* ], line 142 */
                {   int ret = r_R2(); /* call R2, line 142 */
                    if (ret == 0) { c = l - m8; goto lab11; }
                    if (ret < 0) return ret;
                }
                if (slice_del() == -1) return -1; /* delete, line 142 */
                ket = c; /* [, line 142 */
                if (!(eq_s_b(2, s_19))) { c = l - m8; goto lab11; } /* literal, line 142 */
                bra = c; /* ], line 142 */
                {   int m9 = l - c; (void)m9; /* or, line 142 */
                    {   int ret = r_R2(); /* call R2, line 142 */
                        if (ret == 0) goto lab13;
                        if (ret < 0) return ret;
                    }
                    if (slice_del() == -1) return -1; /* delete, line 142 */
                    goto lab12;
                lab13:
                    c = l - m9;
                    {   int ret = slice_from_s(3, s_20); /* <-, line 142 */
                        if (ret < 0) return ret;
                    }
                }
            lab12:
            lab11:
                ;
            }
            break;
        case 9:
            {   int ret = slice_from_s(3, s_21); /* <-, line 144 */
                if (ret < 0) return ret;
            }
            break;
        case 10:
            {   int ret = r_R1(); /* call R1, line 145 */
                if (ret <= 0) return ret;
            }
            {   int ret = slice_from_s(2, s_22); /* <-, line 145 */
                if (ret < 0) return ret;
            }
            break;
        case 11:
            {   int m10 = l - c; (void)m10; /* or, line 147 */
                {   int ret = r_R2(); /* call R2, line 147 */
                    if (ret == 0) goto lab15;
                    if (ret < 0) return ret;
                }
                if (slice_del() == -1) return -1; /* delete, line 147 */
                goto lab14;
            lab15:
                c = l - m10;
                {   int ret = r_R1(); /* call R1, line 147 */
                    if (ret <= 0) return ret;
                }
                {   int ret = slice_from_s(3, s_23); /* <-, line 147 */
                    if (ret < 0) return ret;
                }
            }
        lab14:
            break;
        case 12:
            {   int ret = r_R1(); /* call R1, line 150 */
                if (ret <= 0) return ret;
            }
            if (out_grouping_b_U(g_v, 97, 251, 0)) return 0; /* non v, line 150 */
            if (slice_del() == -1) return -1; /* delete, line 150 */
            break;
        case 13:
            {   int ret = r_RV(); /* call RV, line 155 */
                if (ret <= 0) return ret;
            }
            {   int ret = slice_from_s(3, s_24); /* <-, line 155 */
                if (ret < 0) return ret;
            }
            return 0; /* fail, line 155 */
            break;
        case 14:
            {   int ret = r_RV(); /* call RV, line 156 */
                if (ret <= 0) return ret;
            }
            {   int ret = slice_from_s(3, s_25); /* <-, line 156 */
                if (ret < 0) return ret;
            }
            return 0; /* fail, line 156 */
            break;
        case 15:
            {   int m_test11 = l - c; /* test, line 158 */
                if (in_grouping_b_U(g_v, 97, 251, 0)) return 0; /* grouping v, line 158 */
                {   int ret = r_RV(); /* call RV, line 158 */
                    if (ret <= 0) return ret;
                }
                c = l - m_test11;
            }
            if (slice_del() == -1) return -1; /* delete, line 158 */
            return 0; /* fail, line 158 */
            break;
    }
    return 1;
}

int Xapian::InternalStemFrench::r_i_verb_suffix() { /* backwardmode */
    int among_var;
    {   int m1 = l - c; (void)m1; /* setlimit, line 163 */
        int mlimit1;
        if (c < I_pV) return 0;
        c = I_pV; /* tomark, line 163 */
        mlimit1 = lb; lb = c;
        c = l - m1;
        ket = c; /* [, line 164 */
        if (c <= lb || p[c - 1] >> 5 != 3 || !((68944418 >> (p[c - 1] & 0x1f)) & 1)) { lb = mlimit1; return 0; } /* substring, line 164 */
        among_var = find_among_b(s_pool, a_5, 35, 0, 0);
        if (!(among_var)) { lb = mlimit1; return 0; }
        bra = c; /* ], line 164 */
        switch(among_var) { /* among, line 164 */
            case 0: { lb = mlimit1; return 0; }
            case 1:
                if (out_grouping_b_U(g_v, 97, 251, 0)) { lb = mlimit1; return 0; } /* non v, line 170 */
                if (slice_del() == -1) return -1; /* delete, line 170 */
                break;
        }
        lb = mlimit1;
    }
    return 1;
}

int Xapian::InternalStemFrench::r_verb_suffix() { /* backwardmode */
    int among_var;
    {   int m1 = l - c; (void)m1; /* setlimit, line 174 */
        int mlimit1;
        if (c < I_pV) return 0;
        c = I_pV; /* tomark, line 174 */
        mlimit1 = lb; lb = c;
        c = l - m1;
        ket = c; /* [, line 175 */
        among_var = find_among_b(s_pool, a_6, 38, 0, 0); /* substring, line 175 */
        if (!(among_var)) { lb = mlimit1; return 0; }
        bra = c; /* ], line 175 */
        switch(among_var) { /* among, line 175 */
            case 0: { lb = mlimit1; return 0; }
            case 1:
                {   int ret = r_R2(); /* call R2, line 177 */
                    if (ret == 0) { lb = mlimit1; return 0; }
                    if (ret < 0) return ret;
                }
                if (slice_del() == -1) return -1; /* delete, line 177 */
                break;
            case 2:
                if (slice_del() == -1) return -1; /* delete, line 185 */
                break;
            case 3:
                if (slice_del() == -1) return -1; /* delete, line 190 */
                {   int m2 = l - c; (void)m2; /* try, line 191 */
                    ket = c; /* [, line 191 */
                    if (c <= lb || p[c - 1] != 'e') { c = l - m2; goto lab0; }
                    c--;
                    bra = c; /* ], line 191 */
                    if (slice_del() == -1) return -1; /* delete, line 191 */
                lab0:
                    ;
                }
                break;
        }
        lb = mlimit1;
    }
    return 1;
}

int Xapian::InternalStemFrench::r_residual_suffix() { /* backwardmode */
    int among_var;
    {   int m1 = l - c; (void)m1; /* try, line 199 */
        ket = c; /* [, line 199 */
        if (c <= lb || p[c - 1] != 's') { c = l - m1; goto lab0; }
        c--;
        bra = c; /* ], line 199 */
        {   int m_test2 = l - c; /* test, line 199 */
            if (out_grouping_b_U(g_keep_with_s, 97, 232, 0)) { c = l - m1; goto lab0; } /* non keep_with_s, line 199 */
            c = l - m_test2;
        }
        if (slice_del() == -1) return -1; /* delete, line 199 */
    lab0:
        ;
    }
    {   int m3 = l - c; (void)m3; /* setlimit, line 200 */
        int mlimit3;
        if (c < I_pV) return 0;
        c = I_pV; /* tomark, line 200 */
        mlimit3 = lb; lb = c;
        c = l - m3;
        ket = c; /* [, line 201 */
        among_var = find_among_b(s_pool, a_7, 7, 0, 0); /* substring, line 201 */
        if (!(among_var)) { lb = mlimit3; return 0; }
        bra = c; /* ], line 201 */
        switch(among_var) { /* among, line 201 */
            case 0: { lb = mlimit3; return 0; }
            case 1:
                {   int ret = r_R2(); /* call R2, line 202 */
                    if (ret == 0) { lb = mlimit3; return 0; }
                    if (ret < 0) return ret;
                }
                {   int m4 = l - c; (void)m4; /* or, line 202 */
                    if (c <= lb || p[c - 1] != 's') goto lab2;
                    c--;
                    goto lab1;
                lab2:
                    c = l - m4;
                    if (c <= lb || p[c - 1] != 't') { lb = mlimit3; return 0; }
                    c--;
                }
            lab1:
                if (slice_del() == -1) return -1; /* delete, line 202 */
                break;
            case 2:
                {   int ret = slice_from_s(1, s_26); /* <-, line 204 */
                    if (ret < 0) return ret;
                }
                break;
            case 3:
                if (slice_del() == -1) return -1; /* delete, line 205 */
                break;
            case 4:
                if (!(eq_s_b(2, s_27))) { lb = mlimit3; return 0; } /* literal, line 206 */
                if (slice_del() == -1) return -1; /* delete, line 206 */
                break;
        }
        lb = mlimit3;
    }
    return 1;
}

int Xapian::InternalStemFrench::r_un_double() { /* backwardmode */
    {   int m_test1 = l - c; /* test, line 212 */
        if (c - 2 <= lb || p[c - 1] >> 5 != 3 || !((1069056 >> (p[c - 1] & 0x1f)) & 1)) return 0; /* among, line 212 */
        if (!(find_among_b(s_pool, a_8, 5, 0, 0))) return 0;
        c = l - m_test1;
    }
    ket = c; /* [, line 212 */
    {   int ret = skip_utf8(p, c, lb, 0, -1);
        if (ret < 0) return 0;
        c = ret; /* next, line 212 */
    }
    bra = c; /* ], line 212 */
    if (slice_del() == -1) return -1; /* delete, line 212 */
    return 1;
}

int Xapian::InternalStemFrench::r_un_accent() { /* backwardmode */
    {   int i = 1;
        while(1) { /* atleast, line 216 */
            if (out_grouping_b_U(g_v, 97, 251, 0)) goto lab0; /* non v, line 216 */
            i--;
            continue;
        lab0:
            break;
        }
        if (i > 0) return 0;
    }
    ket = c; /* [, line 217 */
    {   int m1 = l - c; (void)m1; /* or, line 217 */
        if (!(eq_s_b(2, s_28))) goto lab2; /* literal, line 217 */
        goto lab1;
    lab2:
        c = l - m1;
        if (!(eq_s_b(2, s_29))) return 0; /* literal, line 217 */
    }
lab1:
    bra = c; /* ], line 217 */
    {   int ret = slice_from_s(1, s_30); /* <-, line 217 */
        if (ret < 0) return ret;
    }
    return 1;
}

int Xapian::InternalStemFrench::stem() { /* forwardmode */
    {   int c1 = c; /* do, line 223 */
        {   int ret = r_prelude(); /* call prelude, line 223 */
            if (ret == 0) goto lab0;
            if (ret < 0) return ret;
        }
    lab0:
        c = c1;
    }
    {   int c2 = c; /* do, line 224 */
        {   int ret = r_mark_regions(); /* call mark_regions, line 224 */
            if (ret == 0) goto lab1;
            if (ret < 0) return ret;
        }
    lab1:
        c = c2;
    }
    lb = c; c = l; /* backwards, line 225 */

    {   int m3 = l - c; (void)m3; /* do, line 227 */
        {   int m4 = l - c; (void)m4; /* or, line 237 */
            {   int m5 = l - c; (void)m5; /* and, line 233 */
                {   int m6 = l - c; (void)m6; /* or, line 229 */
                    {   int ret = r_standard_suffix(); /* call standard_suffix, line 229 */
                        if (ret == 0) goto lab6;
                        if (ret < 0) return ret;
                    }
                    goto lab5;
                lab6:
                    c = l - m6;
                    {   int ret = r_i_verb_suffix(); /* call i_verb_suffix, line 230 */
                        if (ret == 0) goto lab7;
                        if (ret < 0) return ret;
                    }
                    goto lab5;
                lab7:
                    c = l - m6;
                    {   int ret = r_verb_suffix(); /* call verb_suffix, line 231 */
                        if (ret == 0) goto lab4;
                        if (ret < 0) return ret;
                    }
                }
            lab5:
                c = l - m5;
                {   int m7 = l - c; (void)m7; /* try, line 234 */
                    ket = c; /* [, line 234 */
                    {   int m8 = l - c; (void)m8; /* or, line 234 */
                        if (c <= lb || p[c - 1] != 'Y') goto lab10;
                        c--;
                        bra = c; /* ], line 234 */
                        {   int ret = slice_from_s(1, s_31); /* <-, line 234 */
                            if (ret < 0) return ret;
                        }
                        goto lab9;
                    lab10:
                        c = l - m8;
                        if (!(eq_s_b(2, s_32))) { c = l - m7; goto lab8; } /* literal, line 235 */
                        bra = c; /* ], line 235 */
                        {   int ret = slice_from_s(1, s_33); /* <-, line 235 */
                            if (ret < 0) return ret;
                        }
                    }
                lab9:
                lab8:
                    ;
                }
            }
            goto lab3;
        lab4:
            c = l - m4;
            {   int ret = r_residual_suffix(); /* call residual_suffix, line 238 */
                if (ret == 0) goto lab2;
                if (ret < 0) return ret;
            }
        }
    lab3:
    lab2:
        c = l - m3;
    }
    {   int m9 = l - c; (void)m9; /* do, line 243 */
        {   int ret = r_un_double(); /* call un_double, line 243 */
            if (ret == 0) goto lab11;
            if (ret < 0) return ret;
        }
    lab11:
        c = l - m9;
    }
    {   int m10 = l - c; (void)m10; /* do, line 244 */
        {   int ret = r_un_accent(); /* call un_accent, line 244 */
            if (ret == 0) goto lab12;
            if (ret < 0) return ret;
        }
    lab12:
        c = l - m10;
    }
    c = lb;
    {   int c11 = c; /* do, line 246 */
        {   int ret = r_postlude(); /* call postlude, line 246 */
            if (ret == 0) goto lab13;
            if (ret < 0) return ret;
        }
    lab13:
        c = c11;
    }
    return 1;
}

Xapian::InternalStemFrench::InternalStemFrench()
    : I_p2(0), I_p1(0), I_pV(0)
{
}

Xapian::InternalStemFrench::~InternalStemFrench()
{
}

const char *
Xapian::InternalStemFrench::get_description() const
{
    return "french";
}
